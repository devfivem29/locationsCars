Config = {}

Config.RentalVehicles = {
    {name = "Asbo", model = "asbo", price = 5}
}

Config.RentalLocations = {
    {
        coords = {x = 248.6852722168, y = -906.2470703125, z = 29.20237159729},
        spawnPoint = {x = 249.79702758789, y = -902.02307128906, z = 29.109498977661, h = 253.21450805664}
    },
    {
        coords = {x =1349.0863037109, y =3646.9375, z =33.592113494873},
        spawnPoint = {x =1348.2331542969, y = 3641.9919433594, z =33.692600250244, h =132.26895141602}
    },
    -- Add more locations here, for example:
     {
         coords = {x =895.63586425781, y =-0.71446365118027, z =78.903648376465},
         spawnPoint = {x =895.02014160156, y = -5.2438278198242, z =78.76407623291, h =156.2882232666}
     },
}

Config.Blip = {
    sprite = 226,  -- Car sprite
    color = 2,     -- Green color
    scale = 0.8,   -- Size of the blip
    name = "Location de véhicules"  -- Name that appears on the map
}