fx_version 'adamant'
game 'gta5'
lua54 'yes'
author 'lebg29'
description 'Systeme d\'annonce personnalisé'
version '1.0.0'

client_scripts {
    '@es_extended/locale.lua',
    'client.lua',
    'pmenu.lua',
    'config.lua'
}

server_scripts {
    '@es_extended/locale.lua',
   '@oxmysql/lib/MySQL.lua',
    'server.lua',
    'config.lua'
}

dependency '/assetpacks'